print() # (baris kosong)

# Tugas 1 : Program Konversi Suhu
Info1 = '-Berikut merupakan program yang dirancang untuk dapat mengubah suhu dari satuan Celcius menuju Fahrenheit, Kelvin,dan Reamur'
print(Info1)

print() # (baris kosong)

# Input suhu dalam Celcius dari pengguna
celcius = float(input(" Silakan masukkan suhu (dalam Celcius) yang di inginkan: "))

print() # (baris kosong)

print(f'-Berikut menampilkan hasil konversi suhu ke Fahrenheit, Kelvin, dan Reamur dari suhu {celcius} °C')

print() # (baris kosong)

# Mengonversi ke Fahrenheit
fahrenheit = (celcius * 9/5) + 32

# Mengonversi ke Kelvin
kelvin = celcius + 273.15

# Mengonversi ke Reamur
reamur = celcius * 4/5

# Menampilkan hasil konversi suhu
print(f" Suhu dalam Fahrenheit: {fahrenheit} °F")
print(f" Suhu dalam Kelvin: {kelvin} °K")
print(f" Suhu dalam Reamur: {reamur} °R")
