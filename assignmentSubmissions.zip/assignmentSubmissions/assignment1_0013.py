# TEMPERATURE CONVERSION (TUGAS PELATIHAN PYTHON ver.1) utama

# Determine the conversion from the Celcius into the Kelvin, Fahrenheit, and Reamure degree

# User's input
celcius = float(input("Celcius: "))
print('')

# Conversion to Kelvin
kelvin = celcius + 273.15
print("Kelvin: ", kelvin, "K")

# Conversion to Fahrenheit
fahrenheit = ((9/5)*celcius) + 32
print(f"Fahrenheit: {fahrenheit} °F")

# Conversion to Reamure
reamure = (4/5)*celcius
print(f"Reamure: {reamure} °Re")
