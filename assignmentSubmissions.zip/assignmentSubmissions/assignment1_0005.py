nama = input("Masukan nama anda: ")
print(f"Hai, {nama}")

###Disini, saya akan mengerjakan tugas 1, yakni mengenai Konversi Satuan Suhu dari Celcius ke Satuan Kelvin, Fahrenheit, dan Reamur.

celcius = 90
fahrenheit = (celcius * 9/5) + 32
print("%.2f Celcius = %.2f Fahrenheit" %( celcius,fahrenheit ))

celcius = 90
reamur = (celcius * 4/5)
print("%.2r Celcius = %.2r Reamur" %( celcius,reamur ))

celcius = 90
kelvin = celcius + 273
print("%.2f Celcius = %.2f Kelvin" %( celcius,kelvin ))
