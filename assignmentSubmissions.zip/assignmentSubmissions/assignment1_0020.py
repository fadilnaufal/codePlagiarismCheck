print("Masukan suhu dalam Celcius : ")

#Input suhu dari user
c = float(input())

#Konversi ke Fahrenheit,Reamur,dan Kelvin
f = (c*(9/5))+32
r = c*(4/5)
k = c+ 273.15

#Menampilkan hasil konversi
print("Suhu dalam Fahrenheit :",f,"F")
print("Suhu dalam Reamur :",r,"R")
print("Suhu dalam Kelvin :",k,"K")
