print('Kalkulator Suhu Celcius')
celcius = input("Masukkan suhu dalam Celcius: ")
print(f"{(celcius)}° Celcius")
celcius = float(celcius)

kelvin = 273.15
kelvin = float(kelvin)
hasil1 = celcius + kelvin
print(f"{(hasil1)} Kelvin")

from fractions import Fraction

reamur = Fraction(4, 5)
hasil2 = celcius * reamur
print(f"{(hasil2)}° Reamur")

fahrenheit = Fraction(9, 5)
hasil3 = celcius * fahrenheit
hasil3 = float(hasil3)
hasil4 = hasil3 + 32
print(f"{hasil4}° Fahrenheit")

print(f"Berarti, suhu {(celcius)}° Celcius sama dengan {(hasil1)} Kelvin, {(hasil2)}° Reamur, dan {hasil4}° Fahrenheit.")
