# TUGAS 1 DIMULAI DI BAWAH INI
# Pengguna memasukkan input berupa suhu dalam satuan Celcius
# Program akan mengkonversi ke satuan Fahrenheit, Kelvin, dan Reamur
# Program menampilkan hasil konversi

print("\n-----MASUKKAN ANGKA UNTUK KONVERSI CELCIUS KE SATUAN FAHRENHEIT, KELVIN DAN REAMUR-----\n")
celcius = float(input("masukkan suhu dalam celcius ="))
print("suhu adalah = ", celcius, "C")

#FAHRENHEIT
Fahrenheit = ((9/5)*celcius)+32
print("suhu dalam fahrenheit adalah = ", Fahrenheit, "F")

#KELVIN
Kelvin = celcius + 273
print("suhu dalam Kelvin adalah = ",Kelvin, "K")

#REAMUR
reamur = (4/5)*celcius
print("suhu dalam reamur adalah = ", reamur, "R")

#END
print(f'LUAR BIASA, TUGAS PERTAMA BISA DIKERJAKAN, SELAMAT, HORE HORE HORE !!!!!')
