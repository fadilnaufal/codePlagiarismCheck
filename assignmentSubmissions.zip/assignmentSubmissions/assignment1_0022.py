# Fungsi untuk mengkonversi suhu dari Celcius ke Fahrenheit, Kelvin, dan Reamur
def konversi_suhu(celsius):
    # Menghitung konversi dari Celcius ke Fahrenheit menggunakan rumus (C * 9/5) + 32
    fahrenheit = (celsius * 9/5) + 32

    # Menghitung konversi dari Celcius ke Kelvin menggunakan rumus C + 273.15
    kelvin = celsius + 273.15

    # Menghitung konversi dari Celcius ke Reamur menggunakan rumus C * 4/5
    reamur = celsius * 4/5

    # Mengembalikan hasil konversi dalam bentuk Fahrenheit, Kelvin, Reamur
    return fahrenheit, kelvin, reamur

# Memasukan suhu dalam Celcius pada fungsi input () sebagai string kemudian menggunakan float() untuk mengubah menjadi angka desimal
celsius = float(input("Masukkan suhu dalam Celcius: "))

# Memanggil fungsi konversi_suhu dengan parameter suhu Celcius yang sudah di masukan kemudian hasil konversi akan disimpan dalam variabel terpisah
fahrenheit, kelvin, reamur = konversi_suhu(celsius)

# Menampilkan hasil konversi ke layar dan menggunakan format string (f"") untuk menampilkan hasil yang rapi
print(f"Suhu dalam Fahrenheit: {fahrenheit}°F")
print(f"Suhu dalam Kelvin: {kelvin}K")
print(f"Suhu dalam Reamur: {reamur}°Re")
