celcius = input("Enter temperature in Celcius: ")
print(celcius)

kelvin = int(celcius) + 273
print(kelvin)

reamur = int(celcius) * 4/5
print(reamur)

fahrenheit = int(celcius) * 9/5 + 32
print(fahrenheit)
