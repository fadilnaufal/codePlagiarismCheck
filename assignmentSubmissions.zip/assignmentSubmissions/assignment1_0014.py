X = int(input('Celcius = ')) #Input Besar Celcius
#Hasil dari input tersebut
Y = (X + 273.15) #Rumus Celcius to Kelvin
Z = (X * 1.8 + 32) #Rumus Celcius to fahrenheit
A = (X * 0.8) #Rumus Celcius t
print(f"Kelvin = {Y}")
print(f"Fahrenheit = {Z}")
print(f"Reamur = {A}")
