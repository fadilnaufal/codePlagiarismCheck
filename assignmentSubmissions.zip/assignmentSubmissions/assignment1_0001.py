suhu = input('masukkan nilai suhu : ')
print(f'{suhu} Celcius')
Kelvin = float(suhu) + 273
print(f'{Kelvin} Kelvin')
fahrenheit = (float(suhu) * 9/5) + 32
print(f'{fahrenheit} Fahrenheit')
reamur = float(suhu) * 4/5
print(f'{reamur} Reamur')
