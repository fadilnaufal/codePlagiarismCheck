celcius = int(input("the temperature in °C: "))

fahrenheit = (celcius * 9/5) + 32
print ("the temperature in fahrenheit is", fahrenheit)

kelvin = (celcius) + 273,15
print ("the temperature in kelvin is", kelvin)

reamur = (celcius * 4/5)
print ("the temperature in reamur is", reamur)
