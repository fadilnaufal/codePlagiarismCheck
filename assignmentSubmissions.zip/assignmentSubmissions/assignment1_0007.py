# Input suhu dalam Celsius
celsius = float(input("Masukkan suhu dalam satuan Celcius: "))

# Konversi suhu
fahrenheit = (celsius * 9/5) + 32
kelvin = celsius + 273.15
reamur = celsius * 4/5

# Tampilkan hasil konversi
print("Hasil konversi:")
print("Fahrenheit:", fahrenheit, "°F")
print("Kelvin:", kelvin, "K")
print("Reamur:", reamur, "°R")
