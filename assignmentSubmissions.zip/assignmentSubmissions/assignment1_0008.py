#konversi suhu
suhu = float(input("masukkan suhu dalam celcius:"))
#mengkonversi suhu dari celcius ke reamur
reamur = suhu * 4/5

#mengkonversi suhu dari celcius ke fahrenheit
fahrenheit = (suhu * 9/5) + 32

#mengkonversi suhu dari celcius ke Kelvin
kelvin = suhu + 273

print(f"suhu: {reamur}°F")
print(f"suhu: {fahrenheit}°F")
print(f"suhu: {kelvin}°K")
