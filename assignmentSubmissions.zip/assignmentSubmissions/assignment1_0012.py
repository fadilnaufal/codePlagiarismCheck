celcius = float(input("Masukkan nilai suhu dalam °C: "))
fahrenheit = 1.8 * celcius
kelvin = celcius + 273.15
reamur = 0.8 * celcius

print(f"Suhu {celcius} °C, setara dengan :")
print(f"Suhu {fahrenheit} °F")
print(f"Suhu {kelvin} K")
print(f"Suhu {reamur} °R")
