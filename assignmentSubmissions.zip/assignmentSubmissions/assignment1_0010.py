def convert_temperature(celsius):
    fahrenheit = (celsius * 9/5) + 32
    kelvin = celsius + 273.15
    reamur = celsius * 4/5

    return {
        "Fahrenheit": fahrenheit,
        "Kelvin": kelvin,
        "Reamur": reamur
    }
celsius = float(input("Masukkan suhu dalam Celcius: "))
result = convert_temperature(celsius)
print(f"Suhu dalam Fahrenheit: {result['Fahrenheit']}°F")
print(f"Suhu dalam Kelvin: {result['Kelvin']}K")
print(f"Suhu dalam Reamur: {result['Reamur']}°R")
