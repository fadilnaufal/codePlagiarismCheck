print ('Program Konversi Suhu')
celcius = int(input('Suhu dalam Celcius : '))
fahrenheit = (9/5*celcius) + 32
Fahrenheit = round (fahrenheit, 1)
kelvin = 273 + celcius
Kelvin = round (kelvin, 1)
reamur = 4/5 * celcius
Reamur = round (reamur, 1)


print ('\n''Hasil')
print (f'Fahrenheit: {Fahrenheit}°F\nKelvin: {Kelvin}°K\nReamur: {Reamur}°R')
