# Tugas 1 Python
# Program Konversi Suhu

print("TUGAS 1")
print("PROGRAM KONVERSI SUHU DARI CELCIUS KE FAHRENHEIT, KELVIN DAN REAMUR")

celcius = float(input('input suhu celcius:'))
print('suhu adalah =',celcius, 'C')

Fahren= (9/5*celcius)+32
Kelv = celcius + 273.15
Ream = celcius * 4/5

print (celcius,'derajat Celcius =',Fahren,'derajat Fahrenheit')
print (celcius,'derajat Celcius =',Kelv,'derajat Kelvin')
print (celcius,'derajat Celcius =',Ream,'derajat Reamur')
