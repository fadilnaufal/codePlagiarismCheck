print("Masukan suhu dalam Celsius : ")

c = float(input())

f = (c*(9/5))+32
r = c*(4/5)
k = c + 273.15

print("Suhu dalam fahrenheit : ", f, " F")
print("Suhu dalam reamur :", r , " R")
print("Suhu dalam Kelvin :", k, " K")
