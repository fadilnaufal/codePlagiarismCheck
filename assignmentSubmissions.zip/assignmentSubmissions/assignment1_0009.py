#header program
print('Selamat Datang di Temperatur Converter')

# Input dari pengguna
celsius = float(input("Silahkan Masukkan temperatur dalam Celsius: "))

# Konversi temperatur
fahrenheit = (celsius * 9/5) + 32   #rumus celcius ke fahrenheit
kelvin = celsius + 273.15           #rumus celsius ke kelvin
reamur = celsius * 4/5              #rumus celcius ke reamur

# Menampilkan hasil koversi
print(f"Fahrenheit: {fahrenheit} °F")
print(f"Kelvin: {kelvin} K")
print(f"Reamur: {reamur} °Re")
