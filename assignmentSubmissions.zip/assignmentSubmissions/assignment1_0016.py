# Input suhu dalam Celcius dari pengguna
celcius = float(input("Masukkan suhu dalam Celcius: "))

# Mengonversi ke Fahrenheit
fahrenheit = (celcius * 9/5) + 32

# Mengonversi ke Kelvin
kelvin = celcius + 273.15

# Mengonversi ke Reamur
reamur = celcius * 4/5

# Menampilkan hasil konversi
print(f"Suhu dalam Fahrenheit: {fahrenheit}°F")
print(f"Suhu dalam Kelvin: {kelvin}K")
print(f"Suhu dalam Reamur: {reamur}°R")
