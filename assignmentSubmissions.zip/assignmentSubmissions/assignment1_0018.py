# Fungsi untuk konversi suhu dari Celsius
def convert_temperature(celsius):
    # Konversi ke Fahrenheit
    fahrenheit = (celsius * 9/5) + 32
    # Konversi ke Kelvin
    kelvin = celsius + 273.15
    # Konversi ke Reamur
    reamur = celsius * 4/5
    return fahrenheit, kelvin, reamur

# Meminta input dari pengguna
try:
    celsius = float(input("Masukkan suhu dalam Celsius: "))

    # Melakukan konversi
    fahrenheit, kelvin, reamur = convert_temperature(celsius)

    # Menampilkan hasil konversi
    print(f"Suhu dalam Fahrenheit: {fahrenheit:.2f} °F")
    print(f"Suhu dalam Kelvin: {kelvin:.2f} K")
    print(f"Suhu dalam Reamur: {reamur:.2f} °R")
except ValueError:
    print("Input tidak valid. Harap masukkan angka.")
