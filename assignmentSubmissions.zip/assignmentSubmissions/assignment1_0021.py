print(33*"=")
print("Temperature Conversion Calculator")
print(33*"=")

#Temperature Conversion Calculator
print("Ingin konversi ke suhu apa?")
print("1. Celcius ke Fahrenheit")
print("2. Celcius ke Kelvin")
print("3. Celcius ke Reamur")
print("4. Fahrenheit ke Celcius")
print("5. Fahrenheit ke Kelvin")
print("6. Fahrenheit ke Reamur")
print("7. Kelvin ke Celcius")
print("8. Kelvin ke Fahrenheit")
print("9. Kelvin ke Reamur")
print("10. Reamur ke Celcius")
print("11. Reamur ke Fahrenheit")
print("12. Reamur ke Reamur")

Pilihan = input("Pilihlah angka diatas!(1-12) = ")
if Pilihan == "1" :
  Celcius = float(input("Masukan suhu (°C) = "))
  Celcius_to_Fahrenheit = Celcius * (9/5) + 32
  print(f"{Celcius} °C = {Celcius_to_Fahrenheit} °F")

elif Pilihan == "2" :
  Celcius = float(input("Masukan suhu (°C) = "))
  Celcius_to_Kelvin = Celcius + 273.15
  print(f"{Celcius} °C = {Celcius_to_Kelvin} K")

elif Pilihan == "3" :
  Celcius = float(input("Masukan suhu (°C) = "))
  Celcius_to_Reamur = Celcius * (4/5)
  print(f"{Celcius} °C = {Celcius_to_Reamur} °R")

elif Pilihan == "4" :
  Fahrenheit = float(input("Masukan suhu (°F) = "))
  Fahrenheit_to_Celcius = (Fahrenheit - 32) * (5/9)
  print(f"{Fahrenheit} °C = {Fahrenheit_to_Celcius} °C")

elif Pilihan == "5" :
  Fahrenheit = float(input("Masukan suhu (°F) = "))
  Fahrenheit_to_Kelvin = (Fahrenheit - 32) * (5/9) + 273.15
  print(f"{Fahrenheit} °C = {Fahrenheit_to_Kelvin} K")

elif Pilihan == "6" :
  Fahrenheit = float(input("Masukan suhu (°F) = "))
  Fahrenheit_to_Reamur = (Fahrenheit - 32) * (4/5)
  print(f"{Fahrenheit} °C = {Fahrenheit_to_Reamur} °R")

elif Pilihan == "7" :
  Kelvin = float(input("Masukan suhu (K) = "))
  Kelvin_to_Celcius = Kelvin - 273.15
  print(f"{Kelvin} K = {Kelvin_to_Celcius} °C")

elif Pilihan == "8" :
  Kelvin = float(input("Masukan suhu (K) = "))
  Kelvin_to_Fahrenheit = (Kelvin - 273.15) * (9/5)+32
  print(f"{Kelvin} K = {Kelvin_to_Fahrenheit} °F")

elif Pilihan == "9" :
  Kelvin = float(input("Masukan suhu (K) = "))
  Kelvin_to_Reamur = (Kelvin - 273.15) * (4/5)
  print(f"{Kelvin} K = {Kelvin_to_Reamur} °R")

elif Pilihan == "10" :
  Reamur = float(input("Masukan suhu (°R) = "))
  Reamur_to_Celcius = Reamur * (5/4)
  print(f"{Reamur} °R = {Reamur_to_Celcius} °C")

elif Pilihan == "11" :
  Reamur = float(input("Masukan suhu (°R) = "))
  Reamur_to_Fahrenheit = Reamur * (9/4) + 32
  print(f"{Reamur} °R = {Reamur_to_Fahrenheit} °F")

elif Pilihan == "12" :
  Reamur = float(input("Masukan suhu (°R) = "))
  Reamur_to_Kelvin = Reamur * (5/4) + 273.15
  print(f"{Reamur} °R = {Reamur_to_Kelvin} K")
